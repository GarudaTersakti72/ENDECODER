read -p "INPUT TEXT : " text
echo "$text" | xxd -ps
