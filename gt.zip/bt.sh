read -p "INPUT BINARY : " bin;
echo $bin | perl -lpe '$_=pack"B*",$_'
