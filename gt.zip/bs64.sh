read -p "INSERT BASE64 :" text;
echo""
echo "$text" | base64 -d
