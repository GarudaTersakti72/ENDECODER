read -p "INPUT HEXA : " hex;
echo "$hex" | xxd -r
