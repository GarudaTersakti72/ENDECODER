read -p "INPUT TEXT : " txt;
echo "$txt" | perl -lpe '$_=unpack"B*"'
