pkg install apache2 -y
pkg install openssl-tool -y
pkg install vim -y
pkg install perl -y
