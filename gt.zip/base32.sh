echo""
echo "[1] ENCODE BASE32 " | toilet -f term -F border
echo "[2] DECODE BASE32 " | toilet -f term -F border
echo "[5] EXIT          " | toilet -f term -F border
read -p "Choose :" no;

case $no in
1)
sh bs32en.sh
;;
2)
sh bs32.sh
;;
5) exit
;;
*) echo "undefinded"
esac
