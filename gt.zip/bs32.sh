read -p "INPUT BASE32 : " de;
echo "$de" | base32 -d
echo ""
