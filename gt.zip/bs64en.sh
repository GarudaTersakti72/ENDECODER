read -p "INSERT TEXT :" text;
echo""
echo "$text" | base64
