#!/bin/bash
#coded by TUAN B4DUT
#buitenzorgsyndicate.io
#garudatersakti72

clear
echo "ENCODING/DECODING |author : TUAN B4DUT| GARUDA TERSAKTI 72" | toilet -f term -F border --gay
echo""
echo "[1] INSTALL BAHAN " | toilet -f term -F border
echo "[2] ENC/DEC BASE64" | toilet -f term -F border
echo "[3] ENC/DEC BASE32" | toilet -f term -F border
echo "[4] ENC/DEC HEXA  " | toilet -f term -F border
echo "[5] ENC/DEC BINARY" | toilet -f term -F border
echo "[6] WEB OFFICIAL  " | toilet -f term -F border
echo "[0] EXIT          " | toilet -f term -F border
read -p "Choose : " no;

case $no in
1)
sh setup.sh
;;
2)
sh base64.sh
;;
3) sh base32.sh
;;
4) sh hexa.sh
;;
5) sh binary.sh
;;
6) xdg-open https://www.garudatersakti72.id
;;
0) exit
;;
*) echo "undefinded"
esac
