read -p "INPUT TEXT : " bs32;
echo "$bs32" | base32
echo""
